import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";
import { NgxMugenScrollModule } from "ngx-mugen-scroll";

import { AppComponent } from "./app.component";

@NgModule({
  imports: [BrowserModule, FormsModule, NgxMugenScrollModule],
  declarations: [AppComponent],
  bootstrap: [AppComponent]
})
export class AppModule {}
